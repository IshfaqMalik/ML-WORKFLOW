import json
import boto3

import base64

ENDPOINT = 'image-classification-2025-04-16-11-29-51-692'
runtime = boto3.client("sagemaker-runtime")
def lambda_handler(event, context):

    image_data = base64.b64decode(event['body']['image_data'])

    response = runtime.invoke_endpoint(EndpointName=ENDPOINT, 
                               ContentType='image/png', 
                               Body=image_data)
    inferences = json.loads(response['Body'].read().decode('utf-8'))
    event["inferences"] = inferences


    # TODO implement
    return {
        'statusCode': 200,
        'body': event
    }
