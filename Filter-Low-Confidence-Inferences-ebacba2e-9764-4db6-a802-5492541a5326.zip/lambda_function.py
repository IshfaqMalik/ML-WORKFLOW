import json

THRESHOLD = .60

def lambda_handler(event, context):
    try:
        # Parse the JSON string in the 'body'
        body = json.loads(event['body'])

        # Access the 'inferences' key (which is a string)
        inferences_str = body.get("inferences")
        if not inferences_str:
            raise KeyError("Inferences string not found in event body")

        # Parse the inferences string into a list of floats
        inferences = json.loads(inferences_str)

        # Check the threshold
        max_confidence = max(inferences) >= THRESHOLD

        return {
            'statusCode': 200,
            'body': json.dumps({"threshold_met": max_confidence, "max_confidence": max(inferences), "threshold": THRESHOLD, "raw_inferences": inferences})
        }

