import json
import boto3
import base64

s3= boto3.client('s3')

def lambda_handler(event, context):

    key = event['s3_key']
    bucket = event['s3_bucket']

    local_path = '/tmp/image.png'
    s3.download_file(bucket, key, local_path)

    with open(local_path, 'rb') as f:
        image_data = base64.b64encode(f.read())
        
    print("Event:", event.keys())
        
    # TODO implement
    return {
        'statusCode': 200,
        'body': {
            "image_data": image_data,
            "s3_bucket": bucket,
            "s3_key": key,
            "inferences": []
        }
    }
