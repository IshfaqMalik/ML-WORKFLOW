import json
import boto3 
import base64
#from sagemaker.serializers import IdentitySerializer

runtime = boto3.client('sagemaker-runtime')
ENDPOINT = 'image-classification-2025-04-02-10-00-06-371'

def lambda_handler(event, context):

    image = base64.b64decode(event['body']['image_data']) 
    response = runtime.invoke_endpoint(EndpointName=ENDPOINT, ContentType='image/png', Body=image)
    
    inferences = response['Body'].read().decode('utf-8')

    event["inferences"] = inferences
    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps(event)
    }
